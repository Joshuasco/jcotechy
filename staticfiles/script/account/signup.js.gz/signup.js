$(document).ready(
    function() {
        $('.section-2 form input').focus(
            $(this).css('border', '2px solid green!important')
        );
    }
);